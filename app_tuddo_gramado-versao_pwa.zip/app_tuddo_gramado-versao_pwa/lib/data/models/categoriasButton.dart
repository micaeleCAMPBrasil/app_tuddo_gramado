// ignore_for_file: file_names
class CategoriasButoon {
  String name, backgroundImage;
  int route;

  CategoriasButoon({
    required this.name,
    required this.backgroundImage,
    required this.route,
  });
}
