class Config {
  static String key = "ck_66523e32bf21600a5bfc6bee5e717cb5b4b49f66";
  static String screet = "cs_1d72c1f239aca3c0ff30eb57467df5dfc17d862b";
  static String url = "https://site.tuddogramado.com.br/wp-json/wp/v2/";

  static String tokenURL =
      "https://site.tuddogramado.com.br/wp-json/jwt-auth/v1/token";

  static String urltuddoemdobro =
      "https://site.tuddogramado.com.br/member-login";

  static String customerURL = "users";

  static String keyTuddo = "ck_cb2df5443274c43598be235672b89a63d564ede5";
  static String screetTuddo = "cs_a714a885c4d431248c7efab7bbaaf3205e395478";
  static String urlTuddo = "https://tuddogramado.com.br/wp-json/wp/v2/";

  static String tokenURLTG =
      "https://tuddogramado.com.br/wp-json/jwt-auth/v1/token";

  static String urltuddogramado = "https://tuddogramado.com.br/wp-login.php";

  static String urlTuddoTransfer =
      "https://transfer.tuddogramado.com.br/wp-json/wp/v2/";

  static String tokenURLTransfer =
      "https://transfer.tuddogramado.com.br/wp-json/jwt-auth/v1/token";

  static String urltranfer =
      "https://transfer.tuddogramado.com.br/wp-login.php";
}
